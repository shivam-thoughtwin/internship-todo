const User = require("./user");
const Todo = require("./todo");

module.exports = { User, Todo };
