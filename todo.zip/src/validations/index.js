const auth = require('./auth.validation');

module.exports = {
  auth,
};
